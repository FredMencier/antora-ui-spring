'use strict'

module.exports = (s) => (s ? s.split(',') : [])
